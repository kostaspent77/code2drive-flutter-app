import 'dart:math';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:image/image.dart' as img;

class CameraPage extends StatefulWidget {
  const CameraPage({super.key});

  @override
  State<CameraPage> createState() => _CameraPageState();
}

class _CameraPageState extends State<CameraPage> {
  Database? _database;
  Map<String, dynamic>? selectedSign;
  File? userImage;

  @override
  void initState() {
    super.initState();
    _initDatabase();
  }

  Future<void> _initDatabase() async {
    final databasePath = await getDatabasesPath();
    final path = join(databasePath, 'Testing.db');
    _database = await openDatabase(path);
    await _loadRandomSign();
  }

  Future<void> _loadRandomSign() async {
    if (_database != null) {
      final List<Map<String, dynamic>> signs = await _database!.query('traffic_signs');
      if (signs.isNotEmpty) {
        final randomIndex = Random().nextInt(signs.length);
        setState(() {
          selectedSign = signs[randomIndex];
        });
      }
    }
  }

  Future<void> _takePhoto() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.camera);
    if (pickedFile != null) {
      setState(() {
        userImage = File(pickedFile.path);
      });
      bool isSimilar = await _compareImages(userImage!, 'assets/${selectedSign!['image']}');
      String message = isSimilar
          ? 'Great! The signs are similar!'
          : 'Sorry, the signs do not match.';
      _showMessage(message);
    }
  }

  Future<bool> _compareImages(File userImage, String dbImagePath) async {
    try {
      final Uint8List userImageBytes = await userImage.readAsBytes();
      final ByteData dbImageData = await rootBundle.load(dbImagePath);

      final img.Image? userImg = img.decodeImage(userImageBytes);
      final img.Image? dbImg = img.decodeImage(dbImageData.buffer.asUint8List());

      if (userImg == null || dbImg == null) return false;

      // Resize images to the same size for fair comparison
      final img.Image resizedUserImg = img.copyResize(userImg, width: 150, height: 150);
      final img.Image resizedDbImg = img.copyResize(dbImg, width: 150, height: 150);

      // Compare pixel data
      return _comparePixelData(resizedUserImg, resizedDbImg);
    } catch (e) {
      print('Error comparing images: $e');
      return false;
    }
  }

  bool _comparePixelData(img.Image img1, img.Image img2) {
    if (img1.width != img2.width || img1.height != img2.height) return false;

    int differentPixelCount = 0;
    for (int y = 0; y < img1.height; y++) {
      for (int x = 0; x < img1.width; x++) {
        int pixel1 = img1.getPixel(x, y);
        int pixel2 = img2.getPixel(x, y);

        if (pixel1 != pixel2) {
          differentPixelCount++;
        }
      }
    }

    // Threshold for similarity: allow small differences
    double similarity = 1 - (differentPixelCount / (img1.width * img1.height));
    return similarity > 0.8; // 80% similarity threshold
  }

  void _showMessage(String message) {
    showDialog(
      context: this.context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Result'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (selectedSign == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Sign Recognition',
        style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),),
        backgroundColor: const Color.fromARGB(255, 236, 51, 208),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              'Find a sign that looks like this:',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Image.asset('assets/${selectedSign!['image']}',
                height: 150, width: 150, fit: BoxFit.contain),
            const SizedBox(height: 10),
            Text('Sign Title: ${selectedSign!['sign_title']}',
                style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _takePhoto,
              child: const Text('Take Photo'),
            ),
            if (userImage != null)
              Column(
                children: [
                  const SizedBox(height: 10),
                  Image.file(userImage!, height: 150, width: 150, fit: BoxFit.contain),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
