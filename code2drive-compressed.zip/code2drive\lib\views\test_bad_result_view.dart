import 'package:code2drive/main.dart';
import 'package:flutter/material.dart';
import 'package:code2drive/views/Test_view.dart';
import 'package:sqflite/sqflite.dart'; // Ensure sqflite is added as a dependency
import 'package:path/path.dart'; // For using the `join` method

class TestBadResultPage extends StatelessWidget {
  final int correctAnswers;
  final int elapsedSeconds;

  const TestBadResultPage({super.key, required this.correctAnswers, required this.elapsedSeconds});

  // Correct the _updateUserResults method
  Future<void> _updateUserResults() async {
    // Use getDatabasesPath() to get the path of the database directory
    final String dbPath = join(await getDatabasesPath(), 'your_database_name.db');
    
    // Open the database
    final Database db = await openDatabase(dbPath);

    int userId = 1; // Replace with dynamic user ID fetching logic

    List<Map<String, dynamic>> users = await db.query(
      'user',
      where: 'id = ?',
      whereArgs: [userId],
    );

    if (users.isNotEmpty) {
      Map<String, dynamic> user = users.first;

      String timeField = 'Time1';
      String dateField = 'Date1';

      if (user['Date1'].isNotEmpty && user['Time1'].isNotEmpty) {
        if (user['Date2'].isEmpty && user['Time2'].isEmpty) {
          timeField = 'Time2';
          dateField = 'Date2';
        } else if (user['Date3'].isEmpty && user['Time3'].isEmpty) {
          timeField = 'Time3';
          dateField = 'Date3';
        } else if (user['Date4'].isEmpty && user['Time4'].isEmpty) {
          timeField = 'Time4';
          dateField = 'Date4';
        } else {
          await db.update(
            'user',
            {
              'Time1': user['Time2'],
              'Date1': user['Date2'],
              'Time2': user['Time3'],
              'Date2': user['Date3'],
              'Time3': user['Time4'],
              'Date3': user['Date4'],
            },
            where: 'id = ?',
            whereArgs: [userId],
          );
          timeField = 'Time4';
          dateField = 'Date4';
        }
      }

      await db.update(
        'user',
        {
          timeField: elapsedSeconds.toString(),
          dateField: DateTime.now().toIso8601String(),
        },
        where: 'id = ?',
        whereArgs: [userId],
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    int percentage = correctAnswers * 10; // Υπολογισμός ποσοστού
    _updateUserResults(); // Call the update function

    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context); // Επιστροφή στην προηγούμενη σελίδα
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Better luck next time...',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            CircleAvatar(
              radius: 60,
              backgroundColor: Colors.redAccent,
              child: Text(
                '$percentage%',
                style: TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Driving Test Failed',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  children: [
                    Text(
                      '$correctAnswers/10',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text('Results'),
                  ],
                ),
                Column(
                  children: [
                    Text(
                      '${elapsedSeconds ~/ 60}:${(elapsedSeconds % 60).toString().padLeft(2, '0')}',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text('Time'),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const TestPage()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 50),
              ),
              child: const Text(
                'Start New Test',
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.black,
                ),
              ),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const HomePage()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                side: const BorderSide(color: Colors.green),
                padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 50),
              ),
              child: const Text(
                'Back to Home',
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.black,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
